
const WelcomePage = ()=> {
  return (
    <div>

      Hello This is welcome page
    </div>
  )
}